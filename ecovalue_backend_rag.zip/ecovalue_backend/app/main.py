from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import valuation, report, scenarios, health, analytics


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ───────────────────────────────────────────────────────────────
    from app.models.database import init_db
    init_db()
    print("✅ Database initialised")

    # Pre-load RAG index (builds from coefficients on first run, loads from disk after)
    try:
        from app.services.rag_service import get_store
        store = get_store()
        print(f"✅ RAG index ready: {store.count()} documents")
    except Exception as e:
        print(f"⚠ RAG index failed to load: {e}")

    yield
    # ── Shutdown ──────────────────────────────────────────────────────────────


app = FastAPI(
    title="EcoValue India API",
    description=(
        "Ecosystem Services Valuation Engine for India.\n\n"
        "Features: Valuation API · Scenario Comparison · RAG-powered AI Narratives · PDF Reports · SQLite/Postgres Storage"
    ),
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router,      tags=["Health"])
app.include_router(valuation.router,   prefix="/api/v1", tags=["Valuation"])
app.include_router(scenarios.router,   prefix="/api/v1", tags=["Scenarios"])
app.include_router(report.router,      prefix="/api/v1", tags=["Reports"])
app.include_router(analytics.router,   prefix="/api/v1", tags=["Analytics & History"])


@app.get("/")
def root():
    return {
        "name":    "EcoValue India API",
        "version": "2.0.0",
        "docs":    "/docs",
        "endpoints": {
            "health":       "GET  /health",
            "ecosystems":   "GET  /api/v1/ecosystems",
            "valuate":      "POST /api/v1/valuate",
            "compare":      "POST /api/v1/scenarios/compare",
            "narrative":    "POST /api/v1/report/narrative   ← RAG + Groq AI",
            "pdf":          "POST /api/v1/report/pdf",
            "history":      "GET  /api/v1/history",
            "analytics":    "GET  /api/v1/analytics",
            "rag_search":   "GET  /api/v1/rag/search?q=wetland+flood+control",
            "rag_rebuild":  "POST /api/v1/rag/rebuild",
        }
    }


# ── RAG admin endpoints ───────────────────────────────────────────────────────
from fastapi import APIRouter
rag_router = APIRouter(prefix="/api/v1/rag", tags=["RAG Knowledge Base"])

@rag_router.get("/search")
def rag_search(q: str, k: int = 5, ecosystem: str = None, region: str = None):
    """Search the RAG knowledge base directly. Good for debugging what context the AI sees."""
    from app.services.rag_service import get_store, retrieve_context
    store = get_store()
    results = store.query(q, k=k)
    return {
        "query":        q,
        "total_docs":   store.count(),
        "results":      results,
        "context_preview": retrieve_context(q, ecosystem, region, k=3)[:500] + "..."
    }

@rag_router.post("/rebuild")
def rag_rebuild():
    """Force-rebuild the RAG index from current coefficient data."""
    from app.services.rag_service import build_index
    from app.services.vector_store import VectorStore
    store = VectorStore(persist_path="data/rag_index.json")
    count = build_index(store)
    # Update singleton
    import app.services.rag_service as rag_mod
    rag_mod._store = store
    return {"rebuilt": True, "documents_indexed": count}

@rag_router.get("/stats")
def rag_stats():
    """Show RAG index statistics."""
    from app.services.rag_service import get_store
    store = get_store()
    return {
        "total_documents": store.count(),
        "index_path": "data/rag_index.json",
        "document_types": [
            "ecosystem_overview (9)", "ecosystem_service (50+)",
            "regional_multiplier (9)", "land_use_alternative (6)",
            "carbon_pricing (3)", "case_study (5)", "policy_framework (4)"
        ]
    }

app.include_router(rag_router)
